$(document).on('pageinit', '#formulario', function(){  
alert("ahi vamos");
        $(document).on('click', '#registra', function() { // catch the form's submit event
		alert("fase 2");
            
                // Send data to server through the Ajax call
                // action is functionality we want to call and outputJSON is our data
                    $.ajax({url: 'chafa.php',
                        data: {action : 'login', formData : $('#formulario').serialize()},
                        type: 'post',                   
                        async: 'true',
                                                dataType: 'json',
                        beforeSend: function() {
                            // This callback function will trigger before data is sent
                            $.mobile.showPageLoadingMsg(true); // This will show ajax spinner
                        },
                        complete: function() {
                            // This callback function will trigger on data sent/received complete
                            $.mobile.hidePageLoadingMsg(); // This will hide ajax spinner
                        },
                        success: function (result) {
                            if(result.status) {
                                $.mobile.changePage("#second");                         
                            } else {
                                alert('Logon unsuccessful!'); 
                            }
                        },
                        error: function (request,error) {
                            // This callback function will trigger on unsuccessful action                
                            alert('Network error has occurred please try again!');
                        }
                    });                   
                       
            return false; // cancel original event to prevent form submitting
        });    
});