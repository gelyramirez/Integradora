<?php
/*session_start();

if(!isset($_SESSION["session_username"])){
	header("Location: login.php");
	exit();
}

$mysqli = new mysqli("localhost", "root", "", "hackathon");
if ($mysqli->connect_errno) {
    echo "Fallo al conectar a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}*/
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Bienvenid@s - Hackathon 2019</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/themes/hackathon-2019.min.css" />
		<link rel="stylesheet" href="css/themes/jquery.mobile.icons.min.css" />
		<link rel="stylesheet" href="css/sitio.css" />
		<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile.structure-1.4.5.min.css" /> 
		<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script> 
		<script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
		<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
		<script src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>
		<style>
			td{text-align:center;}
			table,th,td{border-collapse: collapse; border: 1px solid black;padding:5px;margin-top:10px;}
			#preview{width: 15%;height: 15%;max-height: 200px;max-width: 200px;}
		</style>
	</head>
	<body>
		<div data-role="page" id="pageone">
			<div data-role="panel" id="mypanel" class="ui-panel-inner" data-display="overlay">
				<ul class="jqm-list ui-alt-icon ui-nodisc-icon ui-listview">
					<li class="ui-first-child"><a href="index.php" class="ui-btn ui-btn-icon-right ui-icon-home">Inicio</a></li>
					<li class="ui-first-child"><a href="logout.php" class="ui-btn ui-btn-icon-right ui-icon-carat-r">Salir</a></li>
				</ul>
			</div><!-- /panel -->
			<div data-role="header">
				<a href="#mypanel" class="ui-btn ui-shadow ui-corner-all ui-btn-inline ui-btn-icon-left ui-icon-bars">Opciones</a>
				<h1>Hackathon 2019</h1>
			</div>

			<div data-role="main" class="ui-content">
				<img id="logo-ut" src="img/banner-2.png" alt="Logotipo UTC"/>
		
				<video id="preview"></video>
				<script type="text/javascript">
				  let scanner = new Instascan.Scanner({ video: document.getElementById('preview') });
				  scanner.addListener('scan', function (content) {
					$("#tabla-resultados").load("busqueda.php?keyword=" + content + "&criterio=folio");
				  });
				  Instascan.Camera.getCameras().then(function (cameras) {
					if (cameras.length > 0) {
					  scanner.start(cameras[0]);
					} else {
					  console.error('No cameras found.');
					}
				  }).catch(function (e) {
					console.error(e);
				  });
				</script>
				<table id="tabla-resultados">
					<tr>
						<th>Nombre(s)</th>
						<th>Apellidos</th>
						<th>Correo</th>
						<!--<th>Matrícula</th>
						<th>Institución</th>-->
						<th>Asis. 1</th>
						<th>Asis. 2</th>
						<th>Asis. 3</th>
					</tr>
				</table>
			</div>

			<div data-role="footer">
				<h1>UT Calvillo - 2019</h1>
			</div>
		</div>
	</body>
</html>